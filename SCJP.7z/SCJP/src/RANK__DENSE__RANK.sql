select * from emp

select ename,sal 
from (select ename,sal, RANK() OVER(ORDER BY sal DESC) sal_rank from emp)
where  sal_rank <=10

select ename,sal 
from (select ename,sal, DENSE_RANK() OVER(ORDER BY sal DESC) sal_rank from emp)
where  sal_rank <=15