package com.tryex;

import static org.junit.Assert.*;

import org.junit.Test;

public class EXStringTest {

	@Test
	public void testM2() {
		EXString ex1= new EXString();
		System.out.println("what is returned  "+ex1.m2());
	}

}
