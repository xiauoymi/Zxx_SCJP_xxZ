package com.tryex;

public class EXString {
	String m2() {

		String s = "ABC"; 

		String s1 = new String("ABC").intern(); 
		return s1.intern();
	}
}
