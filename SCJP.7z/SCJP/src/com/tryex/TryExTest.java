package com.tryex;

import static org.junit.Assert.*;

import org.junit.Test;

public class TryExTest {

	@Test
	public void testM1() {
		TryEx ex1= new TryEx();
		System.out.println("what is returned  "+ex1.m1());
	}

}
