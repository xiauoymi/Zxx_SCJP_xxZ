package com.tryex;

public class TryEx {

	int m1() {
		try {
			return (1);  // ....logic
		} finally {
			// control 
			return (30000000);  // it will over ride above return statement
		}
	}
}
