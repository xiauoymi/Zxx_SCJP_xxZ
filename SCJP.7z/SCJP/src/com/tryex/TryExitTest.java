package com.tryex;

import static org.junit.Assert.*;

import org.junit.Test;

public class TryExitTest {

	@Test
	public void testM1() {
		TryExit ob =  new TryExit();
		ob.m1();
	}

}
