package com.tryex;

public class TryExit {

	int m1() {
		try {
//			return (1);
			System.out.println("try prints");
			System.exit(123);
		} finally {
			System.out.println("FINALLY NEVER EXECUTES");
			return (30000000);  // it will over ride above return statement
		}  // catch or finally
	}

}
