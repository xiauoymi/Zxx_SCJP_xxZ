package com.scjp;

public class AutoBoz {

	public static void main(String args[]) {
		
		int i = 0;
		
		Integer iObj = null;
		
		iObj= i;
		
		System.out.println("value of iObj "+iObj );
		iObj = new Integer (100);
		
		i = iObj;
		System.out.println("value of i is  "+i );
	}
}
