package com.scjp;

public abstract class AbstractEx {
	
	
	abstract final void m1();

}
