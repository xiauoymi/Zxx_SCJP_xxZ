package com.scjp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CollSort {

	public static void main(String args[]) {
		ArrayList <String> al = new ArrayList<String>();
		
		al.add("Ram");
		al.add("Bheem");
		al.add("Zoom");
		
		Collections.sort(al);
		
		System.out.println("List content : "+al);
		
		 Employee e1 = new Employee("sachin");
		 Employee e2 = new Employee("anil");
		 Employee e3 = new Employee("sagar");
		 Employee e4 = new Employee("ganesh");
		 
		/**
		 * Create a list of employees
		 */
		 ArrayList<Employee> list = new ArrayList<Employee>();
		 
		/**
		 * add employees to the list
		 */
		 list.add(e1);
		 list.add(e2);
		 list.add(e3);
		 list.add(e4);
		 
		 Collections.sort(list);
		 
		 Iterator iterator = list.iterator();
		 
		 while (iterator.hasNext()) {
		  
		 /**
		  * get the employee
		  */
		  Employee employee = (Employee) iterator.next();
		  
		 /**
		  * print the employee name
		  */
		 System.out.println(employee.getEmpName());
		  
		  }
		  
		 
	}
}
