package com.accessspecifier;

import static org.junit.Assert.*;

import org.junit.Test;

public class StaticInnerClassTest {

	@Test
	public void testStaticInnerClass() {
		StaticInnerClass.m1();
	}

}
