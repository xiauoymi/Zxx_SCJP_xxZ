package com.accessspecifier;

public class Superthis {

//	 if private will throw error  // is private --- The constructor Superthis() is not visible
//	 private Superthis() {
//	 super();
//	 System.out.println("I AM SUPER CLASS MAN");
//	 }

	Superthis() {
		super();
		System.out.println("I AM SUPER CLASS MAN default");
	}

//	protected Superthis() {
//		super();
//		System.out.println("I AM SUPER CLASS MAN protected ");
//	}

	 public Superthis(int a) {
	 this();
	 System.out.println("I AM public SUPER CLASS MAN");
	 }
	
//	 public Superthis() {
//	 System.out.println("I AM public SUPER CLASS MAN");
//	 }

}

class Sub extends Superthis {

	public Sub() {
		super();
		this();
		System.out.println("I AM SUB CLASS MAN");
	}

}