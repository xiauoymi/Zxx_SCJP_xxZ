package com.accessspecifier;

public class InstanceOf {

	void m(){
		BB obRef  = new BB();
		if(obRef instanceof AA) {
			System.out.println("YES I extends AA");
		}
		if(obRef instanceof Number) {
			System.out.println("YES I extends AA");
		}
		
	}
}

class AA {

	void m(){
		try {
		}						// Syntax error, insert "Finally" to complete BlockStatements
		catch(Exception e) {
		}
		try {
			try {
			}
			catch(Exception e) {
			}
		}
		catch(Exception e) {
		}
	}
}

class BB extends AA {
	
}