package com.accessspecifier;

public class StaticInnerClass {

	public StaticInnerClass() {
		// TODO Auto-generated constructor stub
	}

	static void  m1 () { 
		A.m1();
	}
	
	static class A {
		
		static void  m1 () {
			
		}
	}
}
