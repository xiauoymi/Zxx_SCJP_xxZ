package com.accessspecifier;

class A
{
	synchronized void m1(B b) {
		System.out.println("A m1()......... ");
		b.last();
	}
	synchronized void last() {
		System.out.println("A i will not print bcoz of dead lock ");
	}

}
class B
{
	synchronized void m1(A a) {
		System.out.println("B m1()......... ");
		a.last();
	}
	synchronized void last() {
		System.out.println("B i will not print bcoz of dead lock ");
	}
}
public class DeadLock  implements Runnable{

	A obRefA;
	B obRefB;
	Thread t;
	
	DeadLock() {
		A obRefA = new A();
		B obRefB = new B();
		Thread t = new Thread();
		t.start();
		System.out.println("DeadLock Thread sate :: "+t.getState());
		obRefA.m1(obRefB);
	}
	public void run() {
		System.out.println("run Thread sate :: "+t.getState());
		obRefB.m1(obRefA);
	}
}
