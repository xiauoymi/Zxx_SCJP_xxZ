package com.accessspecifier;

import static org.junit.Assert.*;

import org.junit.Test;

public class DeadLockTest {

	@Test
	public void testDeadLock() {
		new DeadLock();
	}

}
