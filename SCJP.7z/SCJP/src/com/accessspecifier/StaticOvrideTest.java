package com.accessspecifier;

import static org.junit.Assert.*;

import org.junit.Test;

public class StaticOvrideTest {

//	@Test
//	public void testM1() {
//		fail("Not yet implemented");
//	}

	@Test
	public void testM2() {
		subclass obRef = new subclass();
		obRef.m1();
	}

}
