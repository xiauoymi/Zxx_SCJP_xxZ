package com.accessspecifier;

import static org.junit.Assert.*;

import org.junit.Test;

public class SuperthisTest {

	@Test
	public void test() {
		Sub obRef= new Sub();
		
	}

}
