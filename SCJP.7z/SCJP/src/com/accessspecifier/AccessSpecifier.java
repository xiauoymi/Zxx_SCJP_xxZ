package com.accessspecifier;

public class AccessSpecifier {

	int i;
	private int j;
	public int k;
	protected int l;
	/**
	 * @return the i
	 */
	public int getI() {
		return i;
	}
	/**
	 * @param i the i to set
	 */
	public void setI(int i) {
		this.i = i;
	}
	/**
	 * @return the j
	 */
	public int getJ() {
		return j;
	}
	/**
	 * @param j the j to set
	 */
	public void setJ(int j) {
		this.j = j;
	}
	/**
	 * @return the k
	 */
	public int getK() {
		return k;
	}
	/**
	 * @param k the k to set
	 */
	public void setK(int k) {
		this.k = k;
	}
	/**
	 * @return the l
	 */
	public int getL() {
		return l;
	}
	/**
	 * @param l the l to set
	 */
	public void setL(int l) {
		this.l = l;
	}
	
	
}
