package com.accessspecifier;

import static org.junit.Assert.*;

import org.junit.Test;

public class StatciInstanceFlowTest {

	@Test
	public void test() {
		StatciInstanceFlow obRef = new StatciInstanceFlow(1);
//		StatciInstanceFlow obRef1 = new StatciInstanceFlow(2);
//		StatciInstanceFlow obRef2 = new StatciInstanceFlow(3);
//		StatciInstanceFlow obRef3 = new StatciInstanceFlow(4);
		System.out.println("i am junit block");
	}

}
