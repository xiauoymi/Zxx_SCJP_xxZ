package com.accessspecifier;

public class PrivateAccess {

	private void m1(){
		System.out.println("private called ");
	}
	protected void m2(){
		System.out.println("protected called ");
	}
    void m4(){
		System.out.println("default called ");
	}
	public void m3(){
		System.out.println("public called ");
		m1();
		m2();
		m4();
	}

}
