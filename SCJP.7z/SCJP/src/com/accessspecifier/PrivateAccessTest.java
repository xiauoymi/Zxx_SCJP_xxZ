package com.accessspecifier;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class PrivateAccessTest {

	@Test
	public void testM2() {
		PrivateAccess obRef = new PrivateAccess();
		obRef.m3();
	}
	
	@Ignore
	public void testM3() {
		
	}
	
}
