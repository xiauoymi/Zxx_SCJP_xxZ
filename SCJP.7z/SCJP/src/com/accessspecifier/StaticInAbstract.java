package com.accessspecifier;

public class StaticInAbstract {

	public StaticInAbstract() {
		// TODO Auto-generated constructor stub
	}

	public void static m1() {
		
	}
}
