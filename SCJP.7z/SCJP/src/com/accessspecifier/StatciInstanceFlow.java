package com.accessspecifier;

public class StatciInstanceFlow {
	
	int a;
	
	public StatciInstanceFlow(int a) {
		super();
		System.out.println("i am constructor block ");
		this.a = a;
	}
	static {
		System.out.println("i am static block ");
	}
	{
		System.out.println("i am instance block   "+this.a);
		
	}
	
	
}
