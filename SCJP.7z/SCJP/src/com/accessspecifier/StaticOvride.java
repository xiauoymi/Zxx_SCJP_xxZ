package com.accessspecifier;

public class StaticOvride {

	static int i = 12;
	final static int J =13;
	private static int k =12;
	public static void m1() { 
		System.out.println(" SUPER clas ");
	}

	public   void m2() { 
		System.out.println(" SUPER clas ");
	}

}

class subclass extends StaticOvride {

	static int i;
	
	public static void m1() { 
//	public  void m1() {
		System.out.println(" subclass  "+i);
		System.out.println(" subclass  "+J);
//		System.out.println(" subclass  "+k);
//		mm1();
	}

//	public static void m2() { 
//		System.out.println(" SUPER clas ");
//	}
	
	public  void mm1() { 
		m1();
		System.out.println("i value "+i);
	}
}
