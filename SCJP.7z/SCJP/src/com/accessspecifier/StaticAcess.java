package com.accessspecifier;

public class StaticAcess {

	static int i =100;
	int j;
	
	public StaticAcess() {
		// TODO Auto-generated constructor stub
	}

	public void m1() { 
		System.out.println("check static value "+i);
	}
	public static void m2() { 
		System.out.println("check static value "+i);
//		System.out.println("check static value "+j); //  cannot access this j 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticAcess obRef = new StaticAcess();
		
		obRef.m1();
		m2();
	}

}
