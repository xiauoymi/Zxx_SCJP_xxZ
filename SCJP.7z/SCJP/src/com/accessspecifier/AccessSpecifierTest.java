package com.accessspecifier;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccessSpecifierTest {

	@Test
	public void testGetI() {
		AccessSpecifier obRef = new AccessSpecifier();
		obRef.i=101;
		obRef.j=101;
		obRef.k=101;
		obRef.l=101;
		obRef.setI(100);
		obRef.setJ(200);
		obRef.setK(300);
		obRef.setL(400);
		
		System.out.println(obRef.getI() +"   "+obRef.getJ()+"   "+obRef.getK()+"   "+obRef.getL());
	}

}
