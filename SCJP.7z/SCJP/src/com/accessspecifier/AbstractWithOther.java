package com.accessspecifier;

public abstract class AbstractWithOther {

	abstract void m11();
//	abstract void m2();
//	abstract void m3();

	//The abstract method m1 in type AbstractWithOther can only set a visibility modifier, one of public or	 protected
	abstract static void m1();
	static void mm1() {}
	abstract synchronized void m2();
	synchronized void mm2() {};
	abstract strictfp void m3();
	strictfp void mm3() {}
	abstract final void m4();
	abstract private void m5();
	abstract native void m6();
	
	abstract  void m69();
	
	abstract void m7() throws RuntimeException;
	abstract void m8() throws Exception;
	abstract public void m9() throws Exception;
	abstract protected void m10() throws Exception;
}

class abcd extends AbstractWithOther {

	static void m11() {		//This static method cannot hide the instance method from AbstractWithOther
		
	}
	synchronized void m2() {
		
	}
	strictfp void m3() {
		
	}
	native void m69() {     //Native methods do not specify a body
		
	}

	void m7() throws RuntimeException {
		
	}
	void m8() throws Exception{
		
	}
	public void m9() throws Exception {
		
	}
	protected void m10() throws Exception{
		
	}

}