package com.super1;

public class A {
	
	public A() {
		super();
		// TODO Auto-generated constructor stub
	}

	A(int i,int j) {}
}

class B extends A {
	
	public B(int i) {
		super(100,200);
	}

	public B() {
		super();
		// TODO Auto-generated constructor stub
	}

	public B(int i, int j) {
		super(i, j);
		// TODO Auto-generated constructor stub
	}
}
