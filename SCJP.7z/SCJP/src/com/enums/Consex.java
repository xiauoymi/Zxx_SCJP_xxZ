package com.enums;

public class Consex {

	public static int aInt = 100;
}
