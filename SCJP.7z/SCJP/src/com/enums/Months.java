package com.enums;

public enum Months {
	// JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC;

	JAN(1), FEB(2), MAR(3), APR(4), MAY(5), JUN(6), JUL(7), AUG(8), SEP(9), OCT(
			10), NOV(11), DEC(12);

	int monthIndex;

	// Illegal modifier for the enum constructor; only private/default is permitted.
//	 public Months(int monthIndex) {
	private Months(int monthIndex) {
//	 Months(int monthIndex) {
		this.monthIndex = monthIndex;
	}

	public static Months getMonths(int k) {
		return values()[k];
	}

	public int getmonthIndex() {
		return this.monthIndex;
	}

}

//enum a implements Months {
//	
//}
//
//enum b extends Months {
//	
//}
