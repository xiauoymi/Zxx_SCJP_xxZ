package com.enums;

import static org.junit.Assert.*;

import org.junit.Test;

public class MonthsTest {

	@Test
	public void testGetMonths() {
		System.out.println("values of month is :: "+Months.values()[5]);
		System.out.println("values of month is :: "+Months.getMonths(5));
		System.out.println("values of month is :: "+Months.valueOf("JAN").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("FEB").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("MAR").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("APR").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("MAY").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("JUN").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("JUL").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("AUG").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("SEP").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("OCT").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("NOV").getmonthIndex());
		System.out.println("values of month is :: "+Months.valueOf("DEC").getmonthIndex());
//		if (Consex.aInt ==  Months.valueOf("JAN")) {
//			
//		}
	}
}
