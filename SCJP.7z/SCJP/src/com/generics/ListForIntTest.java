package com.generics;

import static org.junit.Assert.*;

import org.junit.Test;

public class ListForIntTest {

	@Test
	public void testM1() {
		ListForInt obRef = new ListForInt();
		obRef.m1();
	}

}
