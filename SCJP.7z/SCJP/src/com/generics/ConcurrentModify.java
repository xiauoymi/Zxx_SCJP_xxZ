package com.generics;

import java.util.List;

public class ConcurrentModify {
	void m1(List<String> listRef)  {
		listRef.add("addzd");
		for(Object it : listRef) {
			listRef.add("dsfasfsfdsaf");
			
			System.out.println("it is :: "+it);
		}

		for(String it : listRef) {
		listRef.add("dsfasfsfdsaf");
		
		System.out.println("it is :: "+it);
	}
	}
}
