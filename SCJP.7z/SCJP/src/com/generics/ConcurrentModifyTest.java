package com.generics;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class ConcurrentModifyTest {

	@Test
	public void testM1() {
		ConcurrentModify ex1 = new ConcurrentModify();
		List<String> listRef = new ArrayList<String>();
		listRef.add("abc");
		listRef.add("def");
		ex1.m1(listRef);
		assertTrue(listRef.size() == 4);
	}

}
