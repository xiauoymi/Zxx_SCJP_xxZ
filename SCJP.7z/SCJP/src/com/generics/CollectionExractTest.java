package com.generics;

import static org.junit.Assert.*;

import org.junit.Test;

public class CollectionExractTest {

	@Test
	public void testM1() {
		CollectionExract obRef = new CollectionExract();
		String str = obRef.m1();
		System.out.println("str  is :: "+str);
		assertTrue(str.equals("B"));
	}

}
