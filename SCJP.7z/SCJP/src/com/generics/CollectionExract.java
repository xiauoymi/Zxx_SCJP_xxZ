package com.generics;

import java.util.HashMap;

public class CollectionExract {

	int a;
	String b;
	
	
	public CollectionExract(int a, String b) {
		super();
		this.a = a;
		this.b = b;
	}


	public CollectionExract() {
		// TODO Auto-generated constructor stub
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + a;
		result = prime * result + ((b == null) ? 0 : b.hashCode());
		return result;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CollectionExract other = (CollectionExract) obj;
		if (a != other.a)
			return false;
		if (b == null) {
			if (other.b != null)
				return false;
		} else if (!b.equals(other.b))
			return false;
		return true;
	}


	String m1() {
		CollectionExract obref = new CollectionExract(1000,"ABC");
		CollectionExract obref1 = new CollectionExract(2000,"DEF");

		HashMap<CollectionExract,String> map= new HashMap<CollectionExract,String>();
		map.put(obref, "A");
		map.put(obref1, "B");

		CollectionExract obref2 = new CollectionExract(2000,"DEF");
		
		return map.get(obref2); 
		
	}
}
