package com.generics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListForInt {

	private Iterator<String> i;

	void m1()  {
//		List<int> listRef2 = new ArrayList<int>();
//		ArrayList<char> listRef1 = new ArrayList<char>();

		ArrayList<String> listRef = new ArrayList<String>();
		listRef.add("A");
		listRef.add("B");
		listRef.add("C");
		listRef.add("D");
		listRef.add("E");

		System.out.println("listRef  1  is "+listRef);
		i = listRef.iterator();
		while(i.hasNext()) {
			if(i.next().equals("C"))  {
				i.remove();
			}
		}
		System.out.println("listRef   2  is "+listRef);
		for(String listREF: listRef ) {
			if(listREF.equals("E"))  {
				listRef.indexOf("E");
//				.remove(listRef.indexOf("E"));
			}
		}
		System.out.println("listRef 3  is "+listRef);

	}
}
