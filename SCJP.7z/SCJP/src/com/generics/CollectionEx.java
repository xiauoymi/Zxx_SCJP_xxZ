package com.generics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CollectionEx<T> {

	void m1(T t)  {
		System.out.println("T is :: "+t);
		List<String> listRef = new ArrayList<String>();
		listRef.add((String) t);
		listRef.add("abc");
		listRef.add("def");
		m1(listRef);
	}

	void m1(List<String> listRef)  {
		listRef.add("addzd");
		for(Object it : listRef) {
			System.out.println("it is :: "+it);
		}
	}
	
	void m2(List<? extends Object> listRef)  {
		listRef.add("addzd");
		for(Object it : listRef) {
			System.out.println("it is :: "+it);
		}
	}

	void mm2(List<? super Object> listRef)  {
		listRef.add("addzd");
		for(Object it : listRef) {
			System.out.println("it is :: "+it);
		}
	}


	void m3(List<?> listRef)  {
		listRef.add("addzd");
		for(Object it : listRef) {
			System.out.println("it is :: "+it);
		}
	}

	void m4(List<Integer> listRef)  {
		listRef.add("addzd");
		listRef.add(new Integer(100));
		for(Object it : listRef) {
			System.out.println("it is :: "+it);
		}
	}

//	void m1(List<Object> listRef)  {
//	}

	public static void main() {
		List<String> obList = new ArrayList<String>();
		obList.add("abc");
//		obList.add(10000);
		
		List<Object> obList1 = new ArrayList<Object>();
// 		Similar to Animal and Dog
		obList1.add("abc"); 
		obList1.add(10000);
		obList1.add(new Double("4525"));
		obList1.add(new Object());

		List<?> obList2 = new ArrayList<Object>();
		obList2.add(obList);
		obList2.add(10000);
		obList2 = obList1;

	}
}
