package com.generics;

//public class SCJP <? extends Number> {
//public class SCJP <?> {		
public class SCJP <T> {
}

class SCJP1  {
	
	public <T> SCJP1() {
		
	}
	
	public <T> SCJP1(T t) {
		
	}
	
	public <T> void m1(T t) {
		

	}
}