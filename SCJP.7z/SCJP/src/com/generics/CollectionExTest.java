package com.generics;

import static org.junit.Assert.*;

import org.junit.Test;

public class CollectionExTest extends CollectionEx {

	@Test
	public void testM1() {
		CollectionEx obRef  = new CollectionEx();
//		obRef.m1("ABC");
//		obRef.m1(100000);
//		obRef.m1(new Float(10.000));
		obRef.m1("");

	}

}
