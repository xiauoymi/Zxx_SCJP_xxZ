package com.generics;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


interface Cate {
	
}

public class Animal {

}

class Cat extends Animal implements Cate{
}

class Dog extends Animal {

	<T>Dog(T t){
		
	}
	Dog(){
		
	}
	<T> void m(T t) {
		List<?> obRef = new ArrayList<Dog>();
		obRef.add(new Dog());
		obRef.add((new Object());
		obRef.add("");
		obRef.add(new Animal());
		obRef.add(new String());
		
		List<?> obRef1 = new ArrayList<Animal>();
		obRef1.add(new Object());
		obRef1.add("");
		obRef1.add(new Animal());
		obRef1.add(new String());
		obRef1.add(new Dog());
		
		List<? extends Animal> obRef2 = new ArrayList<Animal>();
		obRef2.add(new Object());
		obRef2.add("");
		obRef2.add(new String());
		obRef2.add(new Animal());
		obRef2.add(new Dog());
		
		List<? extends Animal> obRef3 = new ArrayList<Dog>();
		List<Animal> obRef3 = new ArrayList<Dog>();
		obRef3.add(new Object());
		obRef3.add("");
		obRef3.add(new Animal());
		obRef3.add(new Dog());
		obRef3.add(new String());
		
		List<? super Animal> obReff3 = new ArrayList<Animal>();
//		List<? super Animal> obReff3 = new ArrayList<Dog>();
		obReff3.add(new Animal());
		obReff3.add(new Dog());
		
		List<? super Cate> obRefff3 = new ArrayList<Cate>();
		obRefff3.add(new Cat());
		obRefff3.add(new Dog());
		
		ArrayList<Animal> obReff = new ArrayList<Animal>();
		obReff.add(new Dog());
		obReff.add(new Animal());
		obReff.add(new Cat());
		m1(obReff);
		m2(obReff);

	}
	
	void m1(List list) {
		list.add("String");
	}
	
	void m2(List<Object> obRefe) {
		m3(obRefe); 
	}
	
	void m3(List<Animal> obRefe) {
		
	}
}


