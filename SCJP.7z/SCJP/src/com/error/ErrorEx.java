package com.error;

import java.util.ArrayList;
import java.util.List;

public class ErrorEx {
	
	public void m1(){
		List<String> obref = new ArrayList<String>();
		try {
			for(;;) {
				obref.add("a");
			}
		}
		catch(Error e){
			System.out.println("The messsage is ::: "+e.getMessage().toString());
			System.out.println("Error Class name is ::: "+e.getClass());

		}
	}

}
