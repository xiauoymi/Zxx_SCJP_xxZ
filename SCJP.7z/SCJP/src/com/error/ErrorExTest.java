package com.error;

import static org.junit.Assert.*;

import org.junit.Test;

public class ErrorExTest {

	@Test
	public void testM1() {
		ErrorEx obref = new ErrorEx();
		obref.m1();
	}

}
