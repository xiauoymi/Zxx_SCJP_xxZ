package com.concurrent.example;

import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class AddOfferTest {

	public static void main(String[] args) {	
		
		//Restricted queue with capacity of 2 elements
		BlockingQueue Q_Offer = new ArrayBlockingQueue(2);	//Only 2 elements can be added	
		
		boolean value = false;
		value =	Q_Offer.offer(5);
		System.out.println("Offer Returned Value:"+value);
		value =	Q_Offer.offer(10);
		System.out.println("Offer Returned Value:"+value);
		value =	Q_Offer.offer(15);
		System.out.println("Offer Returned Value:"+value);	// here it returns false.
	
		for (Object I_Offer : Q_Offer) { 
			Q_Offer.remove();
		}
		//Add() test
		int i = Q_Offer.size();
		System.out.println("Q_Offer Value:"+i);	// here it returns false.
		ArrayList <String> al  = new  ArrayList<String>();
		al.add("A");
		al.add("B");
		al.add("C");
		
//		for (Object I_Offer : al) { 
//			al.remove(0);
//		}
		
		BlockingQueue Q_Add = new ArrayBlockingQueue(2);
		Q_Add.add(5);
		Q_Add.add(10);
//		Q_Add.add(15); //here exception occurs :java.lang.IllegalStateException: Queue full		
		Q_Add.remove();
		Q_Add.remove();
//		Q_Add.remove();
		
		try {
			Q_Add.put(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}