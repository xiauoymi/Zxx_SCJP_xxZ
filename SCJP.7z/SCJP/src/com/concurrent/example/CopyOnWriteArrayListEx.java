package com.concurrent.example;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public class CopyOnWriteArrayListEx {

	public static void main(String[] args) {	
		CopyOnWriteArrayList<String> obRef = new CopyOnWriteArrayList<String>();
		
		obRef.add("A");
		obRef.add("B");
		obRef.add("C");
		obRef.add("D");
		
		for (Object ob : obRef) {
			System.out.println(ob.toString());
			obRef.remove(ob.toString());
		}
		
		System.out.println(obRef.size());
		System.out.println("============================================================================================");
		
		CopyOnWriteArraySet<String> obRef1 = new CopyOnWriteArraySet<String>();
		obRef1.add("A");
		obRef1.add("B");
		obRef1.add("C");
		obRef1.add("D");
		
		for (Object ob : obRef1) {
			System.out.println(ob.toString());
			obRef1.remove(ob.toString());
		}
		
		System.out.println(obRef1.size());
	}
}
