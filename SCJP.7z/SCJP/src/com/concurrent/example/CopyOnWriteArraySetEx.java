package com.concurrent.example;

import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public class CopyOnWriteArraySetEx {

	  public static void main(String[] args) {
	        Set<Integer> numSet = new CopyOnWriteArraySet<Integer>();
	        // Adding 5 elements to the set
	        numSet.add(10);
	        numSet.add(20);
	        numSet.add(30);
	        numSet.add(10);
	        System.out.println("numSet size is "+numSet.size());
	        
	        List<Integer> numList = new CopyOnWriteArrayList<Integer>();
	        // Adding 5 elements to the set
	        numList.add(10);
	        numList.add(20);
	        numList.add(30);
	        numList.add(10);
	        System.out.println("numList size is "+numList.size());
	        
	  }        
}
