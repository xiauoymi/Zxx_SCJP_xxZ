package com.equals.hashcode;

import static org.junit.Assert.*;

import org.junit.Test;

public class HashMapScanTest extends HashMapScan {

	@Test
	public void testM1() {
		HashMapScan obRef = new HashMapScan();
		obRef.m1();
	}

}
