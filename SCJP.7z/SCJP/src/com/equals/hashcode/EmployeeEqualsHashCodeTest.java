package com.equals.hashcode;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Hashtable;

import org.junit.Test;

public class EmployeeEqualsHashCodeTest {

	@Test
	public void testGetEmpName() {
		EmployeeEqualsHashCode obref = new EmployeeEqualsHashCode();
		obref.setEmpName("RAMA");
		EmployeeEqualsHashCode obref1 = new EmployeeEqualsHashCode();
		obref1.setEmpName("RAMA1");
		EmployeeEqualsHashCode obref2 = new EmployeeEqualsHashCode();
		obref2.setEmpName("RAMA2");

		HashMap<EmployeeEqualsHashCode,String> hm = new HashMap<EmployeeEqualsHashCode,String>();
		hm.put(obref, "100");
		hm.put(obref1, "100");
		hm.put(obref2, "100");
		hm.put(null, null);
		hm.put(null, null);
		hm.put(null, null);
		hm.put(null, null);
		hm.put(null, null);
		hm.put(null, null);
		hm.put(null, null);
		hm.put(null, null);
		hm.put(null, null);
		System.out.println(hm.size());
		
//		Hashtable<String,String> hm1 = new Hashtable<String,String>();
//		hm1.put(null, null);
//		hm1.put(null, null);
//		hm1.put(null, null);
//		hm1.put(null, null);
//		hm1.put(null, null);
//		hm1.put(null, null);
//		
//		System.out.println(hm1.size());
	}
}
