package com.equals.hashcode;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayListVersusLinkedTest {

	@Test
	public void testM1() {
		ArrayListVersusLinked obRef = new ArrayListVersusLinked();
		obRef.m1();
	}

	@Test
	public void testM2() {
		ArrayListVersusLinked obRef = new ArrayListVersusLinked();
		obRef.m2();
	}

}
