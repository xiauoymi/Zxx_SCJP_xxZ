package com.equals.hashcode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class HashMapScan {

	void m1() {

		HashMap<String,String> map = new HashMap<String,String>();
		map.put("A", "A");
		map.put("B", "B");
		map.put("C", "C");
		map.put("D", "D");
		
		Set<Map.Entry<String, String>> set = map.entrySet();
		System.out.println("map size is  :: "+map.size());
		for(Map.Entry<String, String> ob : set) {
			System.out.println("each entry is :: "+ob);
			Map.Entry<String, String> mapEntry = ob;
			System.out.println("each entry key and value  is :: "+mapEntry.getKey()+"   "+mapEntry.getValue());
		}

		String[] s = new String[]{"A","A","A"};
		for(String ob : s) {
			System.out.print("    "+ob);
		}
		
		HashSet<String> hashSet = new HashSet<String>();
		hashSet.add("A");
		hashSet.add("B");
		hashSet.add("C");
		hashSet.add("D");
		System.out.println("    ");

		for(Object set1 : hashSet) {
			System.out.print("    "+set1);
		}
 
	}
}

