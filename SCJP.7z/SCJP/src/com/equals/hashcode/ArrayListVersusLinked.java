package com.equals.hashcode;

import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListVersusLinked {

	public void m1() {
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("A");
		arrayList.add("B");
		arrayList.add("C");
		arrayList.add("D");
		arrayList.add("E");
	
		for(Object o : arrayList) {
			System.out.print(" ---  "+o);
		}
		System.out.println("               ");
	}
	public void m2() {
		LinkedList<String> linkedList = new LinkedList<String>();
		linkedList.add("A");
		linkedList.add("B");
		linkedList.add("C");
		linkedList.add("D");
		linkedList.add("E");

		for(Object o : linkedList) {
			System.out.print(" ---  "+o);
		}

	}

}
