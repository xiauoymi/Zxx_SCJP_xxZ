package com.passbyvaluereference;

import static org.junit.Assert.*;

import org.junit.Test;

public class PassByReferenceTest {

	@Test
	public void testM1() {
		PassByReference obRef = new PassByReference();
//		obRef.m1();
//		obRef.m3();
//		obRef.m5();
//		obRef.m7();
		obRef.checkArrayLength();
	}


}
