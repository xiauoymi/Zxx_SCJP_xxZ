package com.passbyvaluereference;

import java.util.ArrayList;

public class PassByReference {

	void m1() {
		StringBuffer s = new StringBuffer();
		s.append("A-----------------------------");
		System.out.println("StringBuffer:  what is s before PassByReference  :: "+s);
		m2(s);
		System.out.println("StringBuffer:  what is s after PassByReference  :: "+s);
	}

	void m2(StringBuffer s) {
		s.append("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
	}
	
	void m3() {
		String s = new String("A+++++++++++++++++++++++++++++++++");
		System.out.println("String:  what is s before PassByReference  :: "+s);
		m4(s);
		System.out.println("String:  what is s after PassByReference  :: "+s);
	}

	void m4(String s) {
		s = s.concat("FINAL");
	}	

	void m5() {
		int s = 1000;
		System.out.println("int:  what is s before PassByReference  :: "+s);
		m6(s);
		System.out.println("int:  what is s after PassByReference  :: "+s);
	}

	void m6(int s) {
		s = s+1000;
	}	

	void m7() {
		Integer  integer = new Integer(1000);
		System.out.println("Integer:  what is s before PassByReference  :: "+integer);
		m8(integer);
		System.out.println("Integer:  what is s after PassByReference  :: "+integer);
	}

	void m8(Integer s) {
		s = s + 5000;
	}	
	
	void checkArrayLength() {
		ArrayList<String>  		obRef = new ArrayList<String>();
		obRef.add("I AM 1");
		System.out.println("ArrayList:  what is size before PassByReference  :: "+obRef.size());
		checkArrayLength1(obRef);
		System.out.println("ArrayList:  what is size after PassByReference  :: "+obRef.size());
	}

	void checkArrayLength1(ArrayList<String> s) {
		System.out.println("what is size   :: "+s.size());
//		s = new ArrayList<String>();
		s.add("I AM 2");
		s.add("I AM 3");
		s.add("I AM 4");
		
	}

}
