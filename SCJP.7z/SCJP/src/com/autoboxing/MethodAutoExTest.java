package com.autoboxing;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

public class MethodAutoExTest {

	@Test
	public void testM1Float() {
		MethodAutoEx obref = new MethodAutoEx();
		obref.m1(1000);
		obref.m1(new Integer(1000));
		obref.m1("ABC",2000);
		obref.m1("ABC",1000,1000,2000);
		obref.m1("ABC",1000,1000,2000,3000);
		obref.m1(10.00);
		obref.m1(10.00f);
//		Assert.assertEquals(true,true);
	}
	
	@Test
	public void testAddition() {
		int x = new Integer(100);
		int y = new Integer(500);
		x = x + y ;
		System.out.println("sum is :: "+x);
	}
}
