package com.autoboxing;

public class MethodAutoEx {

	void m1(Float f) {
		System.out.println("I am Float  version");
	}

	void m1(Double d) {
		System.out.println("I am Double  version");
	}

	void m1(Number n) {
		System.out.println("I am Number  version");
	}

	void m1(String s, int... n) {
		System.out.println("I am int... version");

	}

//	void m11(int... n, String s) {   // The variable argument type int of the method m11 must be the last parameter
//		System.out.println("I am int... version");
//
//	}

	public void m1(Integer n) {
		System.out.println("I am Integer  version");
	}

	void m1(int i) {
		System.out.println("I am int  version");

	}
}
