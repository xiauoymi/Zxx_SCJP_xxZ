package com.overload;

public class OverLoad {

	 void m1(float f) {
	 System.out.println("I am float version");
	 }
	 void m1(Float f) {
	 System.out.println("I am Float version");
	 }
	
	 int m1(Double f) {
	 System.out.println("I am Double version");
	 return 10;
	 }
	int m1(Integer f) {
		System.out.println("I am Integer version");
		return 10;
	}

	void m1(Object o) {
		System.out.println("I am Object version");
	}

	void m1(String o) {
		System.out.println("I am String version");
	}

	void m1(StringBuffer o) {
		System.out.println("I am StringBuffer version");
	}

}
