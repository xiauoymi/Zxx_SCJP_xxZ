package com.overload;

import static org.junit.Assert.*;

import org.junit.Test;

public class OverLoadTest {

	@Test
	public void testM1Float() {
		OverLoad obRef = new OverLoad();
//		obRef.m1("String");
//		obRef.m1(10.00);
//		obRef.m1(10.00f);
//		obRef.m1(new Integer("1000"));
//		obRef.m1(null);

	}

}
