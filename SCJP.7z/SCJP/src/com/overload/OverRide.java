package com.overload;

import java.io.IOException;

public class OverRide {

	void call() {
		A obRef = new A();
		obRef.m1(100f);
		obRef.m2();
		B obRef1 = new B();
		obRef1.m2();

	}
		
}

class A {

//	void m1(Float f) throws Exception {
	protected void m1(Float f) throws Exception {
		
	}
	A m2(Float f) throws Exception {
		return new A();
	}

}
class B extends A {

	@Override
	B m2(Float f) throws Exception {
//		return new B();
		return null;
	}

//	void m1(Float f) throws Exception {
	void m1(Float f) throws Exception {

		//	private void m1(Float f) throws Exception {
//    void m1(Float f) throws IOException {
		
	}
	void m2() {
		
	}

}
